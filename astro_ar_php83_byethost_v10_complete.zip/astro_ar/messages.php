<?php
require_once 'config/config.php'; require_once 'app/helpers.php'; require_login();
$title='الرسائل'; require 'partials/header.php'; ?>
<section class="content full"><section class="panel"><h1>الرسائل</h1><p class="muted">نظام الرسائل والتحالفات سيُربط بمحرك اللاعبين في المرحلة التالية.</p>
<div class="message-placeholder">✉️ لا توجد رسائل جديدة.</div></section></section>
<?php require 'partials/footer.php'; ?>
