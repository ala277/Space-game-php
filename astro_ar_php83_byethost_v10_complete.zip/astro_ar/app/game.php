<?php
declare(strict_types=1);

function update_planet(int $planetId): void {
    $pdo = db();
    $pdo->beginTransaction();

    $st = $pdo->prepare('SELECT * FROM planets WHERE id=? FOR UPDATE');
    $st->execute([$planetId]);
    $p = $st->fetch();
    if (!$p) { $pdo->rollBack(); return; }

    $now = time();
    $last = strtotime($p['last_update']);
    $elapsed = max(0, min($now - $last, 86400));

    $metal = min((float)$p['storage_capacity'], (float)$p['metal'] + (float)$p['metal_rate'] * $elapsed / 3600);
    $crystal = min((float)$p['storage_capacity'], (float)$p['crystal'] + (float)$p['crystal_rate'] * $elapsed / 3600);
    $deuterium = min((float)$p['storage_capacity'], (float)$p['deuterium'] + (float)$p['deuterium_rate'] * $elapsed / 3600);
    $energy = (float)$p['energy'] + (float)$p['energy_rate'] * $elapsed / 3600;

    $q = $pdo->prepare("SELECT * FROM build_queue WHERE planet_id=? AND status='building' ORDER BY id ASC LIMIT 1 FOR UPDATE");
    $q->execute([$planetId]);
    $job = $q->fetch();

    if ($job && strtotime($job['finish_at']) <= $now) {
        if ($job['item_type'] === 'building') {
            $field = $job['item_key'];
            $allowed = ['metal_mine','crystal_mine','deuterium_synth','solar_plant','research_lab','shipyard','metal_storage'];
            if (in_array($field, $allowed, true)) {
                $pdo->prepare("UPDATE planets SET `$field`=? WHERE id=?")->execute([(int)$job['target_level'], $planetId]);
            }
        }
        $pdo->prepare("UPDATE build_queue SET status='done' WHERE id=?")->execute([$job['id']]);
    }

    $pdo->prepare('UPDATE planets SET metal=?, crystal=?, deuterium=?, energy=?, last_update=NOW() WHERE id=?')
        ->execute([$metal, $crystal, $deuterium, $energy, $planetId]);
    $pdo->commit();
}

function building_cost(string $key, int $nextLevel): array {
    $base = [
        'metal_mine'=>[60,15], 'crystal_mine'=>[48,24], 'deuterium_synth'=>[225,75],
        'solar_plant'=>[75,30], 'research_lab'=>[200,100], 'shipyard'=>[400,200], 'metal_storage'=>[500,0],
    ];
    [$m,$c] = $base[$key] ?? [999999999,999999999];
    $factor = pow(1.5, max(0,$nextLevel-1));
    return ['metal'=>(int)ceil($m*$factor), 'crystal'=>(int)ceil($c*$factor), 'time'=>max(20,(int)ceil(60*$factor))];
}

function building_name(string $key): string {
    return [
        'metal_mine'=>'منجم المعادن','crystal_mine'=>'مصفاة البلورات','deuterium_synth'=>'مصنّع الديوتيريوم',
        'solar_plant'=>'محطة الطاقة','research_lab'=>'مختبر الأبحاث','shipyard'=>'حوض بناء السفن','metal_storage'=>'مخزن المعادن'
    ][$key] ?? $key;
}

function queue_building(int $planetId, string $key): array {
    $pdo=db(); update_planet($planetId);
    $st=$pdo->prepare('SELECT * FROM planets WHERE id=?'); $st->execute([$planetId]); $p=$st->fetch();
    if(!$p) return [false,'الكوكب غير موجود.'];
    $allowed=['metal_mine','crystal_mine','deuterium_synth','solar_plant','research_lab','shipyard','metal_storage'];
    if(!in_array($key,$allowed,true)) return [false,'المبنى غير صالح.'];
    $next=(int)$p[$key]+1; $cost=building_cost($key,$next);
    $busy=$pdo->prepare("SELECT COUNT(*) FROM build_queue WHERE planet_id=? AND status='building'"); $busy->execute([$planetId]);
    if((int)$busy->fetchColumn()>0) return [false,'يوجد بناء قيد التنفيذ حالياً.'];
    if($p['metal']<$cost['metal']||$p['crystal']<$cost['crystal']) return [false,'الموارد غير كافية.'];
    $pdo->beginTransaction();
    $pdo->prepare('UPDATE planets SET metal=metal-?,crystal=crystal-? WHERE id=?')->execute([$cost['metal'],$cost['crystal'],$planetId]);
    $finish=date('Y-m-d H:i:s',time()+$cost['time']);
    $pdo->prepare("INSERT INTO build_queue(planet_id,item_type,item_key,target_level,finish_at,status) VALUES(?,?,?,?,?,'building')")
        ->execute([$planetId,'building',$key,$next,$finish]);
    $pdo->commit();
    return [true,'بدأ بناء '.building_name($key).' مستوى '.$next.'.'];
}

/* ---------- الأبحاث ---------- */

function research_catalog(): array {
    return [
        'energy'      => ['name'=>'تقنية الطاقة','icon'=>'⚡','base_m'=>180,'base_c'=>90,'base_time'=>180,'description'=>'تحسن إنتاج الطاقة وتفتح تقنيات متقدمة.'],
        'mining'      => ['name'=>'تقنية التعدين','icon'=>'⛏️','base_m'=>250,'base_c'=>125,'base_time'=>240,'description'=>'تحسن إنتاج المعادن بنسبة صغيرة لكل مستوى.'],
        'navigation'  => ['name'=>'الملاحة الفضائية','icon'=>'🛰️','base_m'=>400,'base_c'=>250,'base_time'=>360,'description'=>'تزيد سرعة الأساطيل وتفتح مهاماً أبعد.'],
        'weapons'     => ['name'=>'تقنية الأسلحة','icon'=>'🔫','base_m'=>500,'base_c'=>300,'base_time'=>420,'description'=>'ترفع قوة الهجوم في المعارك.'],
        'shields'     => ['name'=>'تقنية الدروع','icon'=>'🛡️','base_m'=>500,'base_c'=>350,'base_time'=>420,'description'=>'ترفع نقاط التحمل الدفاعية.'],
        'propulsion'  => ['name'=>'تقنية الدفع','icon'=>'🚀','base_m'=>700,'base_c'=>450,'base_time'=>600,'description'=>'تزيد سرعة السفن بشكل أكبر.'],
    ];
}

function research_cost(string $key,int $next): array {
    $r=research_catalog()[$key]??null;
    if(!$r) return ['metal'=>PHP_INT_MAX,'crystal'=>PHP_INT_MAX,'time'=>PHP_INT_MAX];
    $f=pow(1.7,max(0,$next-1));
    return ['metal'=>(int)ceil($r['base_m']*$f),'crystal'=>(int)ceil($r['base_c']*$f),'time'=>(int)ceil($r['base_time']*$f)];
}

function research_levels(int $userId): array {
    $out=[];
    $st=db()->prepare('SELECT technology_key,level FROM research WHERE user_id=?');
    $st->execute([$userId]);
    foreach($st as $r) $out[$r['technology_key']]=(int)$r['level'];
    return $out;
}

function queue_research(int $userId,int $planetId,string $key): array {
    $catalog=research_catalog();
    if(!isset($catalog[$key])) return [false,'البحث غير موجود.'];
    update_planet($planetId);
    $pdo=db();
    $st=$pdo->prepare('SELECT * FROM planets WHERE id=? AND user_id=?'); $st->execute([$planetId,$userId]); $p=$st->fetch();
    if(!$p) return [false,'الكوكب غير صالح.'];
    if((int)$p['research_lab']<1) return [false,'تحتاج إلى مختبر أبحاث مستوى 1 على الأقل.'];

    $busy=$pdo->prepare("SELECT COUNT(*) FROM research_queue WHERE user_id=? AND status='researching'");
    $busy->execute([$userId]);
    if((int)$busy->fetchColumn()>0) return [false,'يوجد بحث قيد التنفيذ.'];

    $st=$pdo->prepare('SELECT level FROM research WHERE user_id=? AND technology_key=?');
    $st->execute([$userId,$key]); $level=(int)($st->fetchColumn()??0);
    $next=$level+1; $cost=research_cost($key,$next);
    if($p['metal']<$cost['metal']||$p['crystal']<$cost['crystal']) return [false,'الموارد غير كافية.'];

    $pdo->beginTransaction();
    $pdo->prepare('UPDATE planets SET metal=metal-?,crystal=crystal-? WHERE id=?')->execute([$cost['metal'],$cost['crystal'],$planetId]);
    $finish=date('Y-m-d H:i:s',time()+$cost['time']);
    $pdo->prepare("INSERT INTO research_queue(user_id,planet_id,technology_key,target_level,finish_at,status) VALUES(?,?,?,?,?,'researching')")
       ->execute([$userId,$planetId,$key,$next,$finish]);
    $pdo->commit();
    return [true,'بدأ البحث: '.$catalog[$key]['name'].' مستوى '.$next.'.'];
}

function process_research_queue(int $userId): void {
    $pdo=db();
    $st=$pdo->prepare("SELECT * FROM research_queue WHERE user_id=? AND status='researching' AND finish_at<=NOW() ORDER BY id ASC LIMIT 1");
    $st->execute([$userId]); $q=$st->fetch();
    if(!$q) return;
    $pdo->beginTransaction();
    $ins=$pdo->prepare('INSERT INTO research(user_id,technology_key,level) VALUES(?,?,?) ON DUPLICATE KEY UPDATE level=VALUES(level)');
    $ins->execute([$userId,$q['technology_key'],$q['target_level']]);
    $pdo->prepare("UPDATE research_queue SET status='done' WHERE id=?")->execute([$q['id']]);
    $pdo->commit();
}

/* ---------- السفن والأساطيل ---------- */

function ship_catalog(): array {
    return [
        'scout'    => ['name'=>'سفينة استطلاع','icon'=>'🛰️','metal'=>180,'crystal'=>120,'deut'=>20,'attack'=>20,'hull'=>80,'speed'=>14,'cargo'=>50,'time'=>45],
        'fighter'  => ['name'=>'مقاتلة خفيفة','icon'=>'🚀','metal'=>300,'crystal'=>100,'deut'=>30,'attack'=>55,'hull'=>120,'speed'=>12,'cargo'=>0,'time'=>60],
        'heavy'    => ['name'=>'مقاتلة ثقيلة','icon'=>'🛸','metal'=>700,'crystal'=>350,'deut'=>80,'attack'=>130,'hull'=>300,'speed'=>9,'cargo'=>0,'time'=>120],
        'cruiser'  => ['name'=>'طراد','icon'=>'☄️','metal'=>1400,'crystal'=>800,'deut'=>180,'attack'=>280,'hull'=>650,'speed'=>7,'cargo'=>0,'time'=>240],
        'cargo'    => ['name'=>'سفينة شحن','icon'=>'📦','metal'=>500,'crystal'=>300,'deut'=>60,'attack'=>10,'hull'=>180,'speed'=>10,'cargo'=>500,'time'=>100],
        'colony'   => ['name'=>'سفينة مستعمِرة','icon'=>'🌍','metal'=>3000,'crystal'=>2000,'deut'=>500,'attack'=>0,'hull'=>700,'speed'=>6,'cargo'=>0,'time'=>600],
    ];
}

function ship_cost(string $key,int $amount=1): array {
    $s=ship_catalog()[$key]??null;
    if(!$s) return [];
    return ['metal'=>$s['metal']*$amount,'crystal'=>$s['crystal']*$amount,'deuterium'=>$s['deut']*$amount,'time'=>$s['time']*$amount];
}

function shipyard_queue(int $planetId,string $key,int $amount): array {
    $pdo=db(); update_planet($planetId);
    $catalog=ship_catalog();
    if(!isset($catalog[$key])) return [false,'نوع السفينة غير صالح.'];
    $amount=max(1,min(1000,$amount));
    $st=$pdo->prepare('SELECT * FROM planets WHERE id=?');$st->execute([$planetId]);$p=$st->fetch();
    if(!$p) return [false,'الكوكب غير موجود.'];
    if((int)$p['shipyard']<1) return [false,'تحتاج إلى حوض بناء مستوى 1.'];
    $cost=ship_cost($key,$amount);
    if($p['metal']<$cost['metal']||$p['crystal']<$cost['crystal']||$p['deuterium']<$cost['deuterium']) return [false,'الموارد غير كافية.'];

    $pdo->beginTransaction();
    $pdo->prepare('UPDATE planets SET metal=metal-?,crystal=crystal-?,deuterium=deuterium-? WHERE id=?')
        ->execute([$cost['metal'],$cost['crystal'],$cost['deuterium'],$planetId]);
    $finish=date('Y-m-d H:i:s',time()+$cost['time']);
    $pdo->prepare("INSERT INTO ship_queue(planet_id,ship_key,amount,finish_at,status) VALUES(?,?,?,?, 'building')")
        ->execute([$planetId,$key,$amount,$finish]);
    $pdo->commit();
    return [true,'بدأ بناء '.$amount.' × '.$catalog[$key]['name'].'.'];
}

function process_ship_queue(int $planetId): void {
    $pdo=db();
    $st=$pdo->prepare("SELECT * FROM ship_queue WHERE planet_id=? AND status='building' AND finish_at<=NOW() ORDER BY id ASC LIMIT 1");
    $st->execute([$planetId]);$q=$st->fetch();if(!$q)return;
    $pdo->beginTransaction();
    $ins=$pdo->prepare('INSERT INTO ships(planet_id,ship_key,amount) VALUES(?,?,?) ON DUPLICATE KEY UPDATE amount=amount+VALUES(amount)');
    $ins->execute([$planetId,$q['ship_key'],$q['amount']]);
    $pdo->prepare("UPDATE ship_queue SET status='done' WHERE id=?")->execute([$q['id']]);
    $pdo->commit();
}

/* ---------- الأساطيل والمعارك ---------- */

function fleet_distance(int $g1,int $s1,int $p1,int $g2,int $s2,int $p2): int {
    return abs($g1-$g2)*200 + abs($s1-$s2)*10 + abs($p1-$p2) + 1;
}

function fleet_speed_for_ships(array $ships): int {
    $cat=ship_catalog(); $speed=PHP_INT_MAX;
    foreach($ships as $key=>$amount) if($amount>0 && isset($cat[$key])) $speed=min($speed,$cat[$key]['speed']);
    return $speed===PHP_INT_MAX?1:$speed;
}

function create_fleet(int $userId,int $planetId,array $ships,string $name): array {
    $pdo=db(); $cat=ship_catalog();
    $clean=[];
    foreach($ships as $key=>$amount){
        $amount=(int)$amount;
        if($amount>0 && isset($cat[$key])) $clean[$key]=$amount;
    }
    if(!$clean)return[false,'اختر سفينة واحدة على الأقل.'];

    $pdo->beginTransaction();
    $total=0;
    foreach($clean as $key=>$amount){
        $st=$pdo->prepare('SELECT amount FROM ships WHERE planet_id=? AND ship_key=? FOR UPDATE');
        $st->execute([$planetId,$key]);$have=(int)($st->fetchColumn()??0);
        if($have<$amount){$pdo->rollBack();return[false,'عدد السفن المتاح غير كافٍ: '.$cat[$key]['name'].'.'];}
        $total+=$amount;
    }
    foreach($clean as $key=>$amount){
        $pdo->prepare('UPDATE ships SET amount=amount-? WHERE planet_id=? AND ship_key=?')->execute([$amount,$planetId,$key]);
    }
    $pdo->prepare("INSERT INTO fleets(user_id,planet_id,name,mission,status) VALUES(?,?,?,?, 'ready')")
       ->execute([$userId,$planetId,substr($name,0,60),'stationed']);
    $fleetId=(int)$pdo->lastInsertId();
    foreach($clean as $key=>$amount){
        $pdo->prepare('INSERT INTO fleet_ships(fleet_id,ship_key,amount) VALUES(?,?,?)')->execute([$fleetId,$key,$amount]);
    }
    $pdo->commit();
    return [true,$fleetId];
}

function launch_fleet(int $userId,int $fleetId,int $targetPlanetId,string $mission): array {
    $pdo=db(); $pdo->beginTransaction();
    $st=$pdo->prepare('SELECT f.*,p.galaxy fg,p.system fs,p.position fp FROM fleets f JOIN planets p ON p.id=f.planet_id WHERE f.id=? AND f.user_id=? FOR UPDATE');
    $st->execute([$fleetId,$userId]);$f=$st->fetch();
    if(!$f){$pdo->rollBack();return[false,'الأسطول غير موجود.'];}
    if(!in_array($mission,['attack','scout','transport'],true)){$pdo->rollBack();return[false,'المهمة غير صالحة.'];}
    $tp=$pdo->prepare('SELECT * FROM planets WHERE id=?');$tp->execute([$targetPlanetId]);$target=$tp->fetch();
    if(!$target){$pdo->rollBack();return[false,'الكوكب الهدف غير موجود.'];}
    if($targetPlanetId===$f['planet_id']){$pdo->rollBack();return[false,'لا يمكنك إرسال الأسطول إلى الكوكب نفسه.'];}
    $ss=$pdo->prepare('SELECT ship_key,amount FROM fleet_ships WHERE fleet_id=?');$ss->execute([$fleetId]);$ships=$ss->fetchAll();
    $map=[];foreach($ships as $s)$map[$s['ship_key']]=(int)$s['amount'];
    $speed=fleet_speed_for_ships($map);
    $dist=fleet_distance((int)$f['fg'],(int)$f['fs'],(int)$f['fp'],(int)$target['galaxy'],(int)$target['system'],(int)$target['position']);
    $seconds=max(20,(int)ceil($dist*3600/$speed));
    $departure=date('Y-m-d H:i:s');$arrival=date('Y-m-d H:i:s',time()+$seconds);
    $pdo->prepare('UPDATE fleets SET mission=?,target_planet_id=?,target_galaxy=?,target_system=?,target_position=?,departure_at=?,arrival_at=?,status=? WHERE id=?')
      ->execute([$mission,$targetPlanetId,$target['galaxy'],$target['system'],$target['position'],$departure,$arrival,'flying',$fleetId]);
    $pdo->commit();
    return[true,$seconds];
}

function process_arrived_fleets(int $userId): void {
    $pdo=db();
    $st=$pdo->prepare("SELECT f.* FROM fleets f WHERE f.user_id=? AND f.status='flying' AND f.arrival_at<=NOW() ORDER BY f.id ASC LIMIT 5");
    $st->execute([$userId]);$fleets=$st->fetchAll();
    foreach($fleets as $f){
        if($f['mission']==='attack') resolve_attack((int)$f['id']);
        elseif($f['mission']==='scout') resolve_scout((int)$f['id']);
        else resolve_transport((int)$f['id']);
    }
}

function resolve_scout(int $fleetId): void {
    $pdo=db();$pdo->beginTransaction();
    $st=$pdo->prepare('SELECT * FROM fleets WHERE id=? FOR UPDATE');$st->execute([$fleetId]);$f=$st->fetch();
    if(!$f||$f['status']!=='flying'){$pdo->rollBack();return;}
    $pdo->prepare("UPDATE fleets SET status='completed' WHERE id=?")->execute([$fleetId]);
    $pdo->prepare("INSERT INTO combat_reports(attacker_id,defender_id,fleet_id,result,summary,created_at) VALUES(?,?,?,?,?,NOW())")
      ->execute([$f['user_id'],$f['target_planet_id'],$fleetId,'scout','وصلت مهمة الاستطلاع إلى الهدف وعادت بالمعلومات.']);
    $pdo->commit();
}

function resolve_transport(int $fleetId): void {
    // النقل في هذه النسخة يسجل الوصول، وتتم إضافة التجارة لاحقاً.
    $pdo=db();$pdo->beginTransaction();
    $st=$pdo->prepare('SELECT * FROM fleets WHERE id=? FOR UPDATE');$st->execute([$fleetId]);$f=$st->fetch();
    if(!$f||$f['status']!=='flying'){$pdo->rollBack();return;}
    $pdo->prepare("UPDATE fleets SET status='completed' WHERE id=?")->execute([$fleetId]);
    $pdo->prepare("INSERT INTO combat_reports(attacker_id,defender_id,fleet_id,result,summary,created_at) VALUES(?,?,?,?,?,NOW())")
      ->execute([$f['user_id'],$f['target_planet_id'],$fleetId,'transport','وصلت سفينة النقل إلى الهدف بنجاح.']);
    $pdo->commit();
}

function resolve_attack(int $fleetId): void {
    $pdo=db();$pdo->beginTransaction();
    $st=$pdo->prepare('SELECT * FROM fleets WHERE id=? FOR UPDATE');$st->execute([$fleetId]);$f=$st->fetch();
    if(!$f||$f['status']!=='flying'){$pdo->rollBack();return;}

    $tp=$pdo->prepare('SELECT * FROM planets WHERE id=? FOR UPDATE');$tp->execute([$f['target_planet_id']]);$target=$tp->fetch();
    $attShips=[];$ss=$pdo->prepare('SELECT ship_key,amount FROM fleet_ships WHERE fleet_id=?');$ss->execute([$fleetId]);
    foreach($ss as $s)$attShips[$s['ship_key']]=(int)$s['amount'];

    $defShips=[];$ds=$pdo->prepare('SELECT ship_key,amount FROM ships WHERE planet_id=? FOR UPDATE');$ds->execute([$target['id']]);
    foreach($ds as $s)$defShips[$s['ship_key']]=(int)$s['amount'];

    $cat=ship_catalog(); $levels=research_levels((int)$f['user_id']); $dlevels=research_levels((int)$target['user_id']);
    $attackMult=1+0.08*($levels['weapons']??0);
    $defMult=1+0.08*($dlevels['shields']??0);

    $attackPower=0;$attackHull=0;
    foreach($attShips as $k=>$n){$attackPower += $n*$cat[$k]['attack']*$attackMult; $attackHull += $n*$cat[$k]['hull'];}
    $defPower=0;$defHull=0;
    foreach($defShips as $k=>$n){$defPower += $n*$cat[$k]['attack']*$defMult; $defHull += $n*$cat[$k]['hull'];}

    // 3 جولات قتالية، مع تقليل الخسائر حسب فارق القوة.
    for($round=1;$round<=3;$round++){
        if($attackPower<=0||$defPower<=0)break;
        $attackDamage=max(1,$attackPower-$defPower*0.08);
        $defDamage=max(1,$defPower-$attackPower*0.08);
        $defHull-=$attackDamage;
        $attackHull-=$defDamage;
        if($defHull<=0||$attackHull<=0)break;
        $attackPower*=0.82;$defPower*=0.82;
    }

    $attackerWon=$defHull<=0 && $attackHull>0;
    $draw=$defHull>0 && $attackHull>0;
    $result=$attackerWon?'victory':($draw?'draw':'defeat');

    // الخسائر تقريبية حسب نسبة الضرر.
    $attLossRatio=$attackHull<=0?0.85:min(0.9,max(0.05,($defPower>0?$defPower/($attackPower+$defPower):0.1)));
    $defLossRatio=$defHull<=0?0.85:min(0.9,max(0.05,($attackPower>0?$attackPower/($attackPower+$defPower):0.1)));

    foreach($attShips as $k=>$n){
        $loss=(int)ceil($n*$attLossRatio); $keep=max(0,$n-$loss);
        $pdo->prepare('INSERT INTO ships(planet_id,ship_key,amount) VALUES(?,?,?) ON DUPLICATE KEY UPDATE amount=amount+VALUES(amount)')
            ->execute([(int)$f['planet_id'],$k,$keep]);
    }
    foreach($defShips as $k=>$n){
        $loss=(int)ceil($n*$defLossRatio); $keep=max(0,$n-$loss);
        $pdo->prepare('UPDATE ships SET amount=? WHERE planet_id=? AND ship_key=?')->execute([$keep,(int)$target['id'],$k]);
    }

    $summary= $attackerWon ? 'انتصار هجومي: تم اختراق دفاعات الهدف.' : ($draw?'المعركة انتهت بتعادل نسبي.':'فشل الهجوم وتم صد الأسطول.');
    $pdo->prepare("UPDATE fleets SET status='completed' WHERE id=?")->execute([$fleetId]);
    $pdo->prepare("INSERT INTO combat_reports(attacker_id,defender_id,fleet_id,result,summary,created_at) VALUES(?,?,?,?,?,NOW())")
      ->execute([(int)$f['user_id'],(int)$target['user_id'],$fleetId,$result,$summary]);
    $pdo->commit();
}
