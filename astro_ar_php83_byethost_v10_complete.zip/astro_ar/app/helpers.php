<?php
declare(strict_types=1);

function e(string|int|float|null $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        exit('رمز الحماية غير صالح.');
    }
}

function require_login(): void {
    if (empty($_SESSION['user_id'])) redirect('login.php');
}

function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $st = db()->prepare('SELECT * FROM users WHERE id=?');
    $st->execute([$_SESSION['user_id']]);
    return $st->fetch() ?: null;
}

function fmt(int|float $n): string {
    return number_format((float)$n, 0, '.', ',');
}

function time_left(int $seconds): string {
    $seconds = max(0, $seconds);
    $h = intdiv($seconds, 3600);
    $m = intdiv($seconds % 3600, 60);
    $s = $seconds % 60;
    return sprintf('%02d:%02d:%02d', $h, $m, $s);
}

function is_admin(): bool {
    $u = current_user();
    return $u && (int)($u['is_admin'] ?? 0) === 1 && (int)($u['is_banned'] ?? 0) === 0;
}
function require_admin(): void {
    require_login();
    if (!is_admin()) { http_response_code(403); exit('ليس لديك صلاحية الدخول إلى لوحة الإدارة.'); }
}
