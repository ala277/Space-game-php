// Small UI enhancements for the classic space-browser interface.
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.planet-node').forEach((node, i) => {
    node.classList.add('game-tip');
    if (!node.dataset.tip) node.dataset.tip = `كوكب ${i + 1}`;
  });
  document.querySelectorAll('[data-hover]').forEach(el => {
    el.classList.add('game-tip');
    el.dataset.tip = el.dataset.hover;
  });
});
