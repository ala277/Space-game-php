document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-countdown]').forEach(el => {
    const end = Number(el.dataset.countdown) * 1000;
    const tick = () => {
      const sec = Math.max(0, Math.floor((end-Date.now())/1000));
      const h = Math.floor(sec/3600), m=Math.floor((sec%3600)/60), s=sec%60;
      el.textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
      if(sec===0) location.reload();
    };
    tick(); setInterval(tick,1000);
  });
});