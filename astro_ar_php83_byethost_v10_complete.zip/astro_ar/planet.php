<?php
require_once 'config/config.php'; require_once 'app/helpers.php'; require_once 'app/game.php';
require_login(); $pid=(int)$_SESSION['planet_id']; update_planet($pid);
$st=db()->prepare('SELECT * FROM planets WHERE id=?'); $st->execute([$pid]); $p=$st->fetch();
$title='الكوكب'; require 'partials/header.php';
?>
<section class="content full">
<section class="panel planet-overview">
<div class="big-orb">🌍</div>
<div><h1><?= e($p['name']) ?></h1><p>الموقع [<?= e($p['galaxy']) ?>:<?= e($p['system']) ?>:<?= e($p['position']) ?>]</p>
<p>كوكب مستعمر تحت سيطرة الإمبراطورية.</p></div>
</div>
</section>
<div class="grid2">
<section class="panel"><h2>الموارد الحالية</h2>
<div class="resource-list">
<p>🔩 المعادن <b><?= fmt($p['metal']) ?></b> / <?= fmt($p['storage_capacity']) ?></p>
<p>💎 البلورات <b><?= fmt($p['crystal']) ?></b> / <?= fmt($p['storage_capacity']) ?></p>
<p>🟢 الديوتيريوم <b><?= fmt($p['deuterium']) ?></b> / <?= fmt($p['storage_capacity']) ?></p>
<p>⚡ الطاقة <b><?= fmt($p['energy']) ?></b></p>
</div></section>
<section class="panel"><h2>الإنتاج</h2>
<p>المعادن: +<?= fmt($p['metal_rate']) ?>/ساعة</p><p>البلورات: +<?= fmt($p['crystal_rate']) ?>/ساعة</p><p>الديوتيريوم: +<?= fmt($p['deuterium_rate']) ?>/ساعة</p></section>
</div></section>
<?php require 'partials/footer.php'; ?>
