<?php
require_once 'config/config.php'; require_once 'app/helpers.php';
if (!empty($_SESSION['user_id'])) redirect('index.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf();
  $name=trim($_POST['username']??''); $pass=$_POST['password']??'';
  if (!preg_match('/^[A-Za-z0-9_]{3,24}$/',$name)) $error='اسم اللاعب يجب أن يكون 3-24 حرفاً إنجليزياً أو رقماً أو _.';
  elseif(strlen($pass)<8) $error='كلمة المرور يجب أن تكون 8 أحرف على الأقل.';
  else {
    try {
      $pdo=db(); $pdo->beginTransaction();
      $st=$pdo->prepare('INSERT INTO users(username,password_hash,points) VALUES(?,?,0)');
      $st->execute([$name,password_hash($pass,PASSWORD_DEFAULT)]);
      $uid=(int)$pdo->lastInsertId();
      $pdo->prepare("INSERT INTO planets(user_id,name,galaxy,system,position,metal,crystal,deuterium,energy,metal_rate,crystal_rate,deuterium_rate,energy_rate,storage_capacity) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        ->execute([$uid,'العالم الجديد',1,1,rand(1,12),500,300,150,100,30,15,8,10,10000]);
      $pid=(int)$pdo->lastInsertId();
      $pdo->prepare('UPDATE users SET home_planet_id=? WHERE id=?')->execute([$pid,$uid]);
      $starterShips = ['scout'=>3,'fighter'=>5,'cargo'=>2];
      foreach ($starterShips as $shipKey=>$amount) {
        $pdo->prepare('INSERT INTO ships(planet_id,ship_key,amount) VALUES(?,?,?)')->execute([$pid,$shipKey,$amount]);
      }

      $pdo->commit();
      $_SESSION['user_id']=$uid; $_SESSION['planet_id']=$pid;
      redirect('index.php');
    } catch(Throwable $e) { if(db()->inTransaction()) db()->rollBack(); $error='تعذر إنشاء الحساب. قد يكون الاسم مستخدماً.'; }
  }
}
$dashboard=false;
$title='إنشاء حساب'; require 'partials/header.php';
?>
<div class="auth-wrap"><section class="panel auth">
<h1>إنشاء إمبراطورية</h1>
<?php if($error): ?><div class="error"><?= e($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
<label>اسم اللاعب<input name="username" required maxlength="24"></label>
<label>كلمة المرور<input type="password" name="password" required minlength="8"></label>
<button class="button wide">بدء الاستعمار</button>
</form>
<p><a href="login.php">لدي حساب بالفعل</a></p>
</section></div>
<?php require 'partials/footer.php'; ?>
