<?php
require_once 'config/config.php'; require_once 'app/helpers.php'; require_once 'app/game.php';
require_login(); $uid=(int)$_SESSION['user_id']; $pid=(int)$_SESSION['planet_id'];
update_planet($pid); process_ship_queue($pid); process_arrived_fleets($uid);
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf(); $action=$_POST['action']??'';
    if($action==='build_ship'){
        [$ok,$msg]=shipyard_queue($pid,$_POST['ship_key']??'',(int)($_POST['amount']??1));
        $_SESSION['flash']=[$ok,$msg]; redirect('fleet.php');
    }
    if($action==='create_fleet'){
        $ships=[]; foreach(array_keys(ship_catalog()) as $k)$ships[$k]=(int)($_POST['ships'][$k]??0);
        [$ok,$res]=create_fleet($uid,$pid,$ships,trim($_POST['name']??'أسطول جديد'));
        $_SESSION['flash']=[$ok,$ok?'تم إنشاء الأسطول رقم '.$res:$res]; redirect('fleet.php');
    }
    if($action==='launch'){
        [$ok,$res]=launch_fleet($uid,(int)$_POST['fleet_id'],(int)$_POST['target_planet_id'],$_POST['mission']??'attack');
        $_SESSION['flash']=[$ok,$ok?'انطلق الأسطول. زمن الوصول: '.time_left($res):$res]; redirect('fleet.php');
    }
}
$flash=$_SESSION['flash']??null;unset($_SESSION['flash']);
$cat=ship_catalog(); $st=db()->prepare('SELECT ship_key,amount FROM ships WHERE planet_id=? ORDER BY ship_key');$st->execute([$pid]);$available=[];foreach($st as $s)$available[$s['ship_key']]=(int)$s['amount'];
$fq=db()->prepare("SELECT * FROM ship_queue WHERE planet_id=? AND status='building' ORDER BY id LIMIT 5");$fq->execute([$pid]);$shipQueue=$fq->fetchAll();
$fl=db()->prepare("SELECT f.*,p.name target_name FROM fleets f LEFT JOIN planets p ON p.id=f.target_planet_id WHERE f.user_id=? ORDER BY f.id DESC LIMIT 15");$fl->execute([$uid]);$fleets=$fl->fetchAll();
$others=db()->prepare('SELECT id,name,galaxy,system,position FROM planets WHERE id<>? ORDER BY id LIMIT 20');$others->execute([$pid]);$targets=$others->fetchAll();
$title='الأساطيل'; require 'partials/header.php';
?>
<section class="content full">
<?php if($flash): ?><div class="<?= $flash[0]?'success':'error' ?>"><?= e($flash[1]) ?></div><?php endif; ?>

<section class="panel"><h1>حوض بناء السفن</h1>
<div class="cards"><?php foreach($cat as $key=>$s): $c=ship_cost($key,1); ?>
<article class="game-card"><div class="card-icon"><?= $s['icon'] ?></div><h2><?= e($s['name']) ?></h2>
<p>هجوم <?= $s['attack'] ?> · درع <?= $s['hull'] ?> · سرعة <?= $s['speed'] ?></p>
<p>🔩<?= fmt($c['metal']) ?> · 💎<?= fmt($c['crystal']) ?> · 🟢<?= fmt($c['deuterium']) ?></p>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="build_ship"><input type="hidden" name="ship_key" value="<?= e($key) ?>">
<input type="number" name="amount" value="1" min="1" max="1000" class="qty"><button class="button">بناء</button></form></article>
<?php endforeach; ?></div>
</section>

<section class="panel"><h2>السفن المتاحة</h2>
<div class="stat-grid"><?php foreach($cat as $k=>$s): ?><div><?= $s['icon'] ?> <?= e($s['name']) ?> <b><?= fmt($available[$k]??0) ?></b></div><?php endforeach; ?></div>
<?php foreach($shipQueue as $q): ?><div class="queue-row"><span>بناء <?= (int)$q['amount'] ?> × <?= e($cat[$q['ship_key']]['name']) ?></span><b data-countdown="<?= strtotime($q['finish_at']) ?>">...</b></div><?php endforeach; ?>
</section>

<section class="panel"><h2>إنشاء أسطول</h2>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="create_fleet">
<label>اسم الأسطول <input name="name" value="الأسطول الجديد" maxlength="60"></label>
<div class="stat-grid"><?php foreach($cat as $k=>$s): ?><label><?= $s['icon'] ?> <?= e($s['name']) ?><input class="qty" type="number" min="0" max="<?= $available[$k]??0 ?>" name="ships[<?= e($k) ?>]" value="0"></label><?php endforeach; ?></div>
<button class="button">تجميع الأسطول</button></form>
</section>

<section class="panel"><h2>الأساطيل والمهام</h2>
<?php foreach($fleets as $f): ?>
<div class="queue-row"><span>🚀 <?= e($f['name']) ?> · <?= e($f['status']) ?><?php if($f['target_name']): ?> · الهدف: <?= e($f['target_name']) ?><?php endif; ?></span>
<?php if($f['status']==='ready'): ?><form method="post" style="display:flex;gap:5px"><?= csrf_field() ?><input type="hidden" name="action" value="launch"><input type="hidden" name="fleet_id" value="<?= $f['id'] ?>"><select name="target_planet_id"><?php foreach($targets as $t): ?><option value="<?= $t['id'] ?>"><?= e($t['name']) ?> [<?= $t['galaxy'] ?>:<?= $t['system'] ?>:<?= $t['position'] ?>]</option><?php endforeach; ?></select><select name="mission"><option value="scout">استطلاع</option><option value="attack">هجوم</option><option value="transport">نقل</option></select><button class="button">إطلاق</button></form>
<?php elseif($f['status']==='flying'): ?><b data-countdown="<?= strtotime($f['arrival_at']) ?>">...</b><?php else: ?><span class="ok">مكتملة</span><?php endif; ?>
</div>
<?php endforeach; ?>
</section>

<section class="panel"><h2>تقارير المعارك والمهام</h2>
<?php $rp=db()->prepare('SELECT * FROM combat_reports WHERE attacker_id=? OR defender_id=? ORDER BY id DESC LIMIT 10');$rp->execute([$uid,$uid]);$reports=$rp->fetchAll(); ?>
<?php foreach($reports as $r): ?><div class="queue-row"><span><?= $r['result']==='victory'?'🏆':($r['result']==='defeat'?'⚠️':'📡') ?> <?= e($r['summary']) ?></span><small><?= e($r['created_at']) ?></small></div><?php endforeach; ?>
</section>
</section>
<?php require 'partials/footer.php'; ?>
