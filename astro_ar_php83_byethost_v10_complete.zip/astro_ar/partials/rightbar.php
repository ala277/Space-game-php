<?php
$uid = (int)($_SESSION['user_id'] ?? 0);
$tops = db()->query('SELECT username,points FROM users ORDER BY points DESC LIMIT 10')->fetchAll();
$activities = [];
if ($uid) {
    $st = db()->prepare('SELECT summary,created_at,result FROM combat_reports WHERE attacker_id=? OR defender_id=? ORDER BY id DESC LIMIT 6');
    $st->execute([$uid,$uid]);
    foreach ($st->fetchAll() as $r) {
        $activities[] = ['time'=>date('H:i', strtotime($r['created_at'])), 'text'=>$r['summary'], 'class'=>$r['result']==='defeat'?'bad':($r['result']==='victory'?'good':'')];
    }
    $st = db()->prepare("SELECT item_key,finish_at FROM build_queue WHERE planet_id=? ORDER BY id DESC LIMIT 3");
    $st->execute([(int)($_SESSION['planet_id'] ?? 0)]);
    foreach ($st->fetchAll() as $r) {
        $activities[] = ['time'=>date('H:i', strtotime($r['finish_at'])), 'text'=>'عملية بناء: '.building_name($r['item_key']), 'class'=>'good'];
    }
}
usort($activities, fn($a,$b)=>strcmp($b['time'],$a['time']));
$activities=array_slice($activities,0,7);
$alliances = [
 ['النجوم الحرة','78.654.230'],['الإمبراطورية المجرة','62.331.450'],['الفيلق المظلم','51.776.330'],['القوات المتحدة','42.998.110'],['إنفينيتي','37.221.760'],['حراس الفضاء','29.654.330'],['الإخوة','24.887.650'],['التحالفات','18.776.420'],['تحالف النجوم','14.332.110'],['الحلم الكوني','11.987.660']
];
?>
<aside class="rightbar">
  <section class="panel rank-panel">
    <div class="panel-title">أفضل 10 لاعبين</div>
    <div class="rank-head"><span>#</span><span>اللاعب</span><span>النقاط</span></div>
    <?php foreach ($tops as $i=>$u): ?><div class="rank-row"><span><?= $i+1 ?></span><span class="player"><?= e($u['username']) ?></span><b><?= fmt($u['points']) ?></b></div><?php endforeach; ?>
  </section>
  <section class="panel rank-panel">
    <div class="panel-title">أفضل 10 تحالفات</div>
    <div class="rank-head"><span>#</span><span>التحالف</span><span>النقاط</span></div>
    <?php foreach ($alliances as $i=>$a): ?><div class="rank-row"><span><?= $i+1 ?></span><span class="player"><?= e($a[0]) ?></span><b><?= e($a[1]) ?></b></div><?php endforeach; ?>
  </section>
  <section class="panel">
    <div class="panel-title">آخر الأنشطة</div>
    <?php if (!$activities): ?><div class="panel-body muted">لا توجد أنشطة حديثة.</div><?php endif; ?>
    <?php foreach ($activities as $a): ?><div class="activity"><span class="time"><?= e($a['time']) ?></span><span class="<?= e($a['class']) ?>"><?= e($a['text']) ?></span></div><?php endforeach; ?>
  </section>
</aside>
