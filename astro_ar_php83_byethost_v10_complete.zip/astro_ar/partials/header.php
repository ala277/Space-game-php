<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/helpers.php';
require_once __DIR__ . '/../app/game.php';
$dashboard = $dashboard ?? true;
$current = basename($_SERVER['PHP_SELF']);
$user = !empty($_SESSION['user_id']) ? current_user() : null;
if ($dashboard && $user && !empty($_SESSION['planet_id'])) {
    update_planet((int)$_SESSION['planet_id']);
    process_ship_queue((int)$_SESSION['planet_id']);
    process_research_queue((int)$_SESSION['user_id']);
    process_arrived_fleets((int)$_SESSION['user_id']);
    $rst = db()->prepare('SELECT * FROM planets WHERE id=?');
    $rst->execute([(int)$_SESSION['planet_id']]);
    $headerPlanet = $rst->fetch();
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title ?? APP_NAME) ?></title>
<link rel="stylesheet" href="assets/css/game.css">
</head>
<body>
<header class="topbar">
  <div class="brand"><div class="logo">إمبراطوريات<br>النجوم<span>SPACE EMPIRE</span></div></div>
  <nav>
    <a class="<?= $current==='index.php'?'active':'' ?>" href="index.php"><span class="nav-ico">⌂</span>الرئيسية</a>
    <a class="<?= $current==='planet.php'?'active':'' ?>" href="planet.php"><span class="nav-ico">♟</span>الإمبراطورية</a>
    <a class="<?= $current==='fleet.php'?'active':'' ?>" href="fleet.php"><span class="nav-ico">✈</span>الأساطيل</a>
    <a class="<?= $current==='research.php'?'active':'' ?>" href="research.php"><span class="nav-ico">⌕</span>الأبحاث</a>
    <a class="<?= $current==='buildings.php'?'active':'' ?>" href="buildings.php"><span class="nav-ico">▥</span>المباني</a>
    <a href="messages.php"><span class="nav-ico">♜</span>التحالف</a>
    <a class="<?= $current==='messages.php'?'active':'' ?>" href="messages.php"><span class="nav-ico">✉</span>الرسائل</a>
    <a class="<?= $current==='ranking.php'?'active':'' ?>" href="ranking.php"><span class="nav-ico">♟</span>التصنيف</a>
    <a href="logout.php"><span class="nav-ico">⚙</span>الخيارات</a>
    <?php if ($user && (int)($user['is_admin'] ?? 0) === 1): ?><a href="admin/"><span class="nav-ico">🛡️</span>الإدارة</a><?php endif; ?>
  </nav>
  <div class="account">
    <?php if ($user): ?>
      <div>اللاعب : <b><?= e($user['username']) ?></b></div>
      <div>التحالف : <b>لا يوجد</b></div>
      <div>الرتبة : <b><?= fmt((int)$user['points']) ?></b></div>
    <?php endif; ?>
  </div>
</header>
<?php if ($dashboard && $headerPlanet): ?>
<div class="resourcebar">
  <span><span class="ri">▰</span> معدن : <b><?= fmt($headerPlanet['metal']) ?></b> <span class="rate">(+<?= fmt($headerPlanet['metal_rate']) ?>/س)</span></span>
  <span><span class="ri">◆</span> كريستال : <b><?= fmt($headerPlanet['crystal']) ?></b> <span class="rate">(+<?= fmt($headerPlanet['crystal_rate']) ?>/س)</span></span>
  <span><span class="ri">●</span> ديوتيريوم : <b><?= fmt($headerPlanet['deuterium']) ?></b> <span class="rate">(+<?= fmt($headerPlanet['deuterium_rate']) ?>/س)</span></span>
  <span><span class="ri">✦</span> طاقة : <b><?= fmt($headerPlanet['energy']) ?></b> <span class="rate negative"><?= fmt($headerPlanet['energy_rate']) ?>/س</span></span>
</div>
<?php endif; ?>
<?php if ($dashboard): ?><main class="layout"><?php require __DIR__.'/sidebar.php'; ?><section class="content">
<?php else: ?><main class="standalone"><?php endif; ?>
