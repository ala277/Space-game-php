<?php
$uid = (int)($_SESSION['user_id'] ?? 0);
$pid = (int)($_SESSION['planet_id'] ?? 0);
$planet = null;
if ($pid) {
    $st = db()->prepare('SELECT * FROM planets WHERE id=?');
    $st->execute([$pid]);
    $planet = $st->fetch();
}
$current = basename($_SERVER['PHP_SELF']);
$links = [
    ['⌂','نظرة عامة','index.php'],
    ['▰','الموارد','planet.php'],
    ['▥','المباني','buildings.php'],
    ['⌕','الأبحاث','research.php'],
    ['⚙','حوض بناء السفن','fleet.php'],
    ['◈','الدفاعات','buildings.php'],
    ['♟','إدارة الأساطيل','fleet.php'],
    ['●','الكواكب','planet.php'],
    ['◉','المجرة','galaxy.php'],
    ['♜','التحالف','messages.php'],
    ['✉','الرسائل','messages.php'],
    ['♜','التصنيف','ranking.php'],
    ['⚙','الخيارات','logout.php'],
];
$fleets = [];
if ($uid) {
    $st = db()->prepare("SELECT f.*,p.name target_name FROM fleets f LEFT JOIN planets p ON p.id=f.target_planet_id WHERE f.user_id=? ORDER BY f.id DESC LIMIT 3");
    $st->execute([$uid]);
    $fleets = $st->fetchAll();
}
?>
<aside class="sidebar">
  <?php if ($planet): ?>
  <section class="panel planet-card">
    <div class="panel-title">نظرة عامة</div>
    <div class="planet-head">
      <div class="planet-orb"></div>
      <div><strong><?= e($planet['name']) ?></strong><small>[<?= e($planet['galaxy']) ?>:<?= e($planet['system']) ?>:<?= e($planet['position']) ?>]</small><span class="ok">كوكب مستعمر</span></div>
    </div>
    <div class="planet-stats">
      <div><span>▰ معدن</span><b><?= fmt($planet['metal']) ?></b></div>
      <div><span>◆ كريستال</span><b><?= fmt($planet['crystal']) ?></b></div>
      <div><span>● ديوتيريوم</span><b><?= fmt($planet['deuterium']) ?></b></div>
      <div><span>✦ طاقة</span><b><?= fmt($planet['energy']) ?></b></div>
    </div>
  </section>
  <?php endif; ?>
  <section class="panel side-menu">
    <div class="panel-title">التنقل</div>
    <?php foreach ($links as $l): $active = $current === $l[2]; ?>
      <a class="<?= $active ? 'active' : '' ?>" href="<?= e($l[2]) ?>"><span class="sico"><?= $l[0] ?></span><?= e($l[1]) ?></a>
    <?php endforeach; ?>
  </section>
  <section class="panel">
    <div class="panel-title">الأساطيل المتحركة</div>
    <?php if (!$fleets): ?><div class="panel-body muted">لا توجد أساطيل في الطريق.</div><?php endif; ?>
    <?php foreach ($fleets as $i=>$f): ?>
      <div class="fleet-mini"><div class="ship-ico">✈</div><div><b><?= $i+1 ?>. <?= e($f['name']) ?></b><small><?= e($planet['name'] ?? 'الكوكب') ?> → <?= e($f['target_name'] ?? '—') ?></small><small class="green"><?= $f['status']==='flying' ? 'الوصول: '.e($f['arrival_at']) : 'جاهز' ?></small></div></div>
    <?php endforeach; ?>
  </section>
</aside>
