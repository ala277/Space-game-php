<?php if (($dashboard ?? true)): ?></section><?php require __DIR__.'/rightbar.php'; ?></main><?php else: ?></main><?php endif; ?>
<footer>الإمبراطوريات الفضائية — PHP 8.3 · واجهة عربية مستقلة بطابع ألعاب الاستراتيجية الفضائية</footer>
<script src="assets/js/game.js"></script>
<script src="assets/js/ui_enhancements.js"></script>
</body></html>
