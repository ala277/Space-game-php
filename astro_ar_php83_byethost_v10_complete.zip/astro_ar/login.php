<?php
require_once 'config/config.php'; require_once 'app/helpers.php';
if (!empty($_SESSION['user_id'])) redirect('index.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf();
  $st=db()->prepare('SELECT * FROM users WHERE username=?');
  $st->execute([trim($_POST['username']??'')]); $u=$st->fetch();
  if ($u && (int)($u['is_banned'] ?? 0) === 1) {
    $error='هذا الحساب موقوف من الإدارة.';
  } elseif ($u && password_verify($_POST['password']??'', $u['password_hash'])) {
    session_regenerate_id(true);
    $_SESSION['user_id']=$u['id']; $_SESSION['planet_id']=$u['home_planet_id'];
    redirect('index.php');
  }
  $error='بيانات الدخول غير صحيحة.';
}
$dashboard=false;
$title='تسجيل الدخول'; require 'partials/header.php';
?>
<div class="auth-wrap"><section class="panel auth">
<h1>تسجيل الدخول</h1>
<?php if($error): ?><div class="error"><?= e($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
<label>اسم اللاعب<input name="username" required></label>
<label>كلمة المرور<input type="password" name="password" required></label>
<button class="button wide">دخول إلى الإمبراطورية</button>
</form>
<p>لا تملك حساباً؟ <a href="register.php">إنشاء حساب</a></p>
</section></div>
<?php require 'partials/footer.php'; ?>
