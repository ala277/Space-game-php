<?php
require_once 'config/config.php'; require_once 'app/helpers.php'; require_once 'app/game.php';
require_login(); process_arrived_fleets((int)$_SESSION['user_id']);
$uid=(int)$_SESSION['user_id'];
$st=db()->prepare('SELECT r.*,a.username attacker_name,d.username defender_name FROM combat_reports r JOIN users a ON a.id=r.attacker_id LEFT JOIN users d ON d.id=r.defender_id WHERE r.attacker_id=? OR r.defender_id=? ORDER BY r.id DESC LIMIT 50');
$st->execute([$uid,$uid]);$reports=$st->fetchAll();
$title='تقارير المعارك'; require 'partials/header.php';
?>
<section class="content full"><section class="panel"><h1>تقارير المعارك والمهام</h1>
<?php foreach($reports as $r): ?>
<article class="game-card" style="text-align:right;margin-bottom:8px">
<strong><?= $r['result']==='victory'?'🏆 انتصار':($r['result']==='defeat'?'⚠️ هزيمة':($r['result']==='draw'?'⚖️ تعادل':'📡 مهمة')) ?></strong>
<p><?= e($r['summary']) ?></p><small><?= e($r['created_at']) ?> · المهاجم: <?= e($r['attacker_name']) ?> · المدافع: <?= e($r['defender_name']??'غير معروف') ?></small>
</article>
<?php endforeach; if(!$reports): ?><p class="muted">لا توجد تقارير بعد.</p><?php endif; ?>
</section></section>
<?php require 'partials/footer.php'; ?>
