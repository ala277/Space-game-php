<?php
require_once 'config/config.php'; require_once 'app/helpers.php'; require_once 'app/game.php';
require_login();
$uid=(int)$_SESSION['user_id']; $planetId=(int)($_SESSION['planet_id']??0);
update_planet($planetId); process_ship_queue($planetId); process_research_queue($uid); process_arrived_fleets($uid);
$st=db()->prepare('SELECT * FROM planets WHERE id=?');$st->execute([$planetId]);$planet=$st->fetch();
$title='الرئيسية'; require 'partials/header.php';
$q=db()->prepare("SELECT * FROM build_queue WHERE planet_id=? AND status='building' ORDER BY id LIMIT 3");$q->execute([$planetId]);$jobs=$q->fetchAll();
$fl=db()->prepare("SELECT f.*,p.name target_name FROM fleets f LEFT JOIN planets p ON p.id=f.target_planet_id WHERE f.user_id=? ORDER BY f.id DESC LIMIT 3");$fl->execute([$uid]);$fleets=$fl->fetchAll();
?>
<section class="panel hero">
  <div class="hero-head"><b>النظام الشمسي [<?=e($planet['galaxy'])?>:<?=e($planet['system'])?>]</b><span class="arrows">‹ النظام السابق &nbsp;&nbsp; النظام التالي ›</span><span>عرض: <select><option>الكواكب</option><option>المدارات</option></select></span></div>
  <div class="solar"><div class="starfield"></div><div class="sun"></div><div class="orbit o1"></div><div class="orbit o2"></div><div class="orbit o3"></div><div class="orbit o4"></div><div class="orbit o5"></div>
    <div class="planet-node earth p1 selected"></div><span class="planet-label" style="left:46%;top:28%">[<?=e($planet['galaxy'])?>:<?=e($planet['system'])?>:<?=$planet['position']?>]</span>
    <div class="planet-node gold p2"></div><span class="planet-label" style="left:69%;top:36%">[1:<?=$planet['system']?>:8]</span>
    <div class="planet-node p3"></div><span class="planet-label" style="left:52%;top:57%">[1:<?=$planet['system']?>:3]</span>
    <div class="planet-node gold p4"></div><span class="planet-label" style="left:17%;top:69%">[1:<?=$planet['system']?>:6]</span>
    <div class="planet-node p5"></div><span class="planet-label" style="left:30%;top:79%">[1:<?=$planet['system']?>:7]</span>
    <div class="planet-node p6"></div><span class="planet-label" style="left:68%;top:75%">[1:<?=$planet['system']?>:9]</span>
    <div class="planet-node p7"></div><span class="planet-label" style="left:12%;top:41%">[1:<?=$planet['system']?>:2]</span>
    <div class="planet-node p8"></div><span class="planet-label" style="left:78%;top:64%">[1:<?=$planet['system']?>:10]</span>
  </div>
</section>
<section class="panel">
  <div class="panel-title"><?=e($planet['name'])?> &nbsp; [<?=e($planet['galaxy'])?>:<?=e($planet['system'])?>:<?=e($planet['position'])?>]</div>
  <div class="planet-detail"><div class="planet-image"><div class="earth-big"></div></div>
    <div class="planet-info"><div class="info-row"><span>النوع</span><span class="value">كوكب معتدل</span></div><div class="info-row"><span>القطر</span><span class="value">12,800 كم</span></div><div class="info-row"><span>الحرارة</span><span class="value">15 °C</span></div><div class="info-row"><span>الموقع</span><span class="value">[<?=e($planet['galaxy'])?>:<?=e($planet['system'])?>:<?=e($planet['position'])?>]</span></div><div class="info-row"><span>السكان</span><span class="value">152,340,000 / 500,000,000</span></div><div class="info-row"><span>الحالة</span><span class="value ok">مستعمر</span></div></div>
    <div class="production"><h3>الموارد <small>(الإنتاج / ساعة)</small></h3><div class="prod-row"><span>▰ معدن</span><b><?=fmt($planet['metal_rate'])?></b></div><div class="prod-row"><span>◆ كريستال</span><b><?=fmt($planet['crystal_rate'])?></b></div><div class="prod-row"><span>● ديوتيريوم</span><b><?=fmt($planet['deuterium_rate'])?></b></div><div class="prod-row"><span>✦ طاقة</span><b class="<?=((int)$planet['energy_rate']<0?'negative':'ok')?>"><?=fmt($planet['energy_rate'])?></b></div></div>
  </div>
</section>
<section class="building-strip">
<?php foreach(['metal_mine','crystal_mine','deuterium_synth','solar_plant','research_lab','shipyard'] as $b): ?><a class="building-tile" href="buildings.php"><div class="building-art"><?=['metal_mine'=>'⛏','crystal_mine'=>'◆','deuterium_synth'=>'♨','solar_plant'=>'☀','research_lab'=>'⚗','shipyard'=>'⚓'][$b]?></div><strong><?=e(building_name($b))?></strong><small>المستوى <?= (int)$planet[$b] ?></small></a><?php endforeach; ?>
</section>
<section class="panel"><div class="panel-title">قائمة البناء</div><table class="queue-table"><thead><tr><th>المبنى / التقنية</th><th>المستوى</th><th>المدة</th><th>النهاية</th><th></th></tr></thead><tbody>
<?php if(!$jobs): ?><tr><td colspan="5" class="muted">لا توجد عمليات بناء حالياً.</td></tr><?php endif; ?>
<?php foreach($jobs as $job): ?><tr><td><?=e(building_name($job['item_key']))?></td><td><?= (int)$job['target_level']?></td><td><?=time_left(max(0,strtotime($job['finish_at'])-time()))?></td><td><?=e($job['finish_at'])?></td><td class="danger">×</td></tr><?php endforeach; ?>
</tbody></table></section>
<?php require 'partials/footer.php'; ?>
