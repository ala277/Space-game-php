<?php
require_once 'config/config.php'; require_once 'app/helpers.php'; require_login();
$users=db()->query('SELECT username,points,created_at FROM users ORDER BY points DESC LIMIT 50')->fetchAll();
$title='التصنيف'; require 'partials/header.php'; ?>
<section class="content full"><section class="panel"><h1>تصنيف الإمبراطوريات</h1>
<table><thead><tr><th>#</th><th>اللاعب</th><th>النقاط</th><th>تاريخ الانضمام</th></tr></thead><tbody>
<?php foreach($users as $i=>$u): ?><tr><td><?= $i+1 ?></td><td><?= e($u['username']) ?></td><td><?= fmt($u['points']) ?></td><td><?= e($u['created_at']) ?></td></tr><?php endforeach; ?>
</tbody></table></section></section>
<?php require 'partials/footer.php'; ?>
