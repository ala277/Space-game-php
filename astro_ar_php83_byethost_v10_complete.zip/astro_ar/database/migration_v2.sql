-- ترقية من النسخة السابقة إلى نظام الأساطيل/المعارك/الأبحاث الفعلي.
-- إذا كنت ستستخدم schema.sql الجديد على قاعدة فارغة فلا تحتاج هذا الملف.

ALTER TABLE planets MODIFY research_lab INT UNSIGNED NOT NULL DEFAULT 1;
ALTER TABLE planets MODIFY shipyard INT UNSIGNED NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS research_queue (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL, planet_id INT UNSIGNED NOT NULL,
 technology_key VARCHAR(40) NOT NULL, target_level INT UNSIGNED NOT NULL,
 finish_at DATETIME NOT NULL,
 status ENUM('researching','done','cancelled') NOT NULL DEFAULT 'researching',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX(user_id,status,finish_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ships (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 planet_id INT UNSIGNED NOT NULL, ship_key VARCHAR(40) NOT NULL,
 amount INT UNSIGNED NOT NULL DEFAULT 0,
 UNIQUE KEY uq_planet_ship(planet_id,ship_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ship_queue (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 planet_id INT UNSIGNED NOT NULL, ship_key VARCHAR(40) NOT NULL,
 amount INT UNSIGNED NOT NULL, finish_at DATETIME NOT NULL,
 status ENUM('building','done','cancelled') NOT NULL DEFAULT 'building',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX(planet_id,status,finish_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fleets (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL, planet_id INT UNSIGNED NOT NULL,
 name VARCHAR(60) NOT NULL, mission VARCHAR(30) NOT NULL DEFAULT 'stationed',
 target_planet_id INT UNSIGNED NULL, target_galaxy SMALLINT UNSIGNED NULL,
 target_system SMALLINT UNSIGNED NULL, target_position TINYINT UNSIGNED NULL,
 departure_at DATETIME NULL, arrival_at DATETIME NULL,
 status VARCHAR(20) NOT NULL DEFAULT 'ready',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX(user_id,status,arrival_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fleet_ships (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 fleet_id BIGINT UNSIGNED NOT NULL, ship_key VARCHAR(40) NOT NULL,
 amount INT UNSIGNED NOT NULL DEFAULT 0,
 UNIQUE KEY uq_fleet_ship(fleet_id,ship_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS combat_reports (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 attacker_id INT UNSIGNED NOT NULL, defender_id INT UNSIGNED NULL,
 fleet_id BIGINT UNSIGNED NULL, result VARCHAR(20) NOT NULL,
 summary VARCHAR(500) NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX(attacker_id,created_at), INDEX(defender_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
