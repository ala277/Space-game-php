# إمبراطوريات النجوم V10

نسخة PHP 8.3 + MariaDB/MySQL، مناسبة للاستضافة المشتركة مثل ByetHost.

## تثبيت جديد
1. أنشئ قاعدة بيانات MySQL/MariaDB.
2. استورد `database/schema.sql` في phpMyAdmin.
3. عدّل `config/config.php` ببيانات القاعدة.
4. ارفع محتويات مجلد `astro_ar` إلى `htdocs`.
5. أنشئ حساباً عادياً ثم اجعله أدمن عبر phpMyAdmin:
   `UPDATE users SET is_admin=1 WHERE username='اسمك';`

## الترقية من V5
لا تحذف قاعدة البيانات. استورد `database/migration_v10.sql` ثم ارفع ملفات V10 فوق ملفات V5.

## الإدارة
لوحة الإدارة: `/admin/`.
تسمح بإدارة اللاعبين، المجرات، الموارد، المباني، الأبحاث، السفن، الأساطيل، التقارير والإعدادات.
