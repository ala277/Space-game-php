<?php
require_once 'config/config.php'; require_once 'app/helpers.php'; require_login();
$gid=max(1,(int)($_GET['galaxy']??1));
$st=db()->prepare('SELECT * FROM galaxies WHERE id=? AND enabled=1');$st->execute([$gid]);$galaxy=$st->fetch();
if(!$galaxy){$galaxy=db()->query('SELECT * FROM galaxies WHERE enabled=1 ORDER BY id LIMIT 1')->fetch();}
if(!$galaxy){http_response_code(404);exit('لا توجد مجرات مفعلة.');}
$system=max(1,min((int)$galaxy['systems'],(int)($_GET['system']??1)));
$st=db()->prepare('SELECT p.*,u.username FROM planets p JOIN users u ON u.id=p.user_id WHERE p.galaxy=? AND p.system=? ORDER BY p.position');$st->execute([(int)$galaxy['id'],$system]);$planets=$st->fetchAll();
$title='المجرة'; require 'partials/header.php'; ?>
<section class="content full"><section class="panel"><div class="galaxy-head"><div><h1>🌌 <?= e($galaxy['name']) ?> · النظام <?= $system ?></h1><p>الإحداثيات: <b><?= (int)$galaxy['id'] ?>:<?= $system ?>:الموقع</b> · <?= (int)$galaxy['positions'] ?> موقعاً</p></div><div><a class="button" href="?galaxy=<?= $galaxy['id'] ?>&system=<?= max(1,$system-1) ?>">‹ السابق</a> <a class="button" href="?galaxy=<?= $galaxy['id'] ?>&system=<?= min((int)$galaxy['systems'],$system+1) ?>">التالي ›</a></div></div>
<div style="margin:10px 0;display:flex;gap:6px;flex-wrap:wrap"><?php foreach(db()->query('SELECT id,name FROM galaxies WHERE enabled=1 ORDER BY id') as $g): ?><a class="button" href="?galaxy=<?= $g['id'] ?>&system=1"><?= e($g['name']) ?></a><?php endforeach; ?></div>
<div class="system-map"><div class="sun">☀️</div><?php for($i=1;$i<=(int)$galaxy['positions'];$i++):$found=null;foreach($planets as $x){if((int)$x['position']===$i){$found=$x;break;}} ?><div class="orbit-row"><span class="pos"><?= $i ?></span><?php if($found): ?><span class="planet-dot">🪐</span><span><?= e($found['username']) ?> — <?= e($found['name']) ?> <small>[<?= $galaxy['id'] ?>:<?= $system ?>:<?= $i ?>]</small></span><?php else: ?><span class="empty">الموقع <?= $i ?> شاغر</span><?php endif; ?></div><?php endfor; ?></div></section></section><?php require 'partials/footer.php'; ?>
