<?php
require_once 'config/config.php'; require_once 'app/helpers.php'; require_once 'app/game.php';
require_login(); $pid=(int)$_SESSION['planet_id']; update_planet($pid);
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf(); [$ok,$msg]=queue_building($pid,$_POST['building']??''); $_SESSION['flash']=[$ok,$msg]; redirect('buildings.php');}
$st=db()->prepare('SELECT * FROM planets WHERE id=?'); $st->execute([$pid]); $p=$st->fetch();
$flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
$items=['metal_mine','crystal_mine','deuterium_synth','solar_plant','research_lab','shipyard','metal_storage'];
$title='المباني'; require 'partials/header.php';
?>
<section class="content full"><section class="panel"><h1>مباني الكوكب</h1>
<?php if($flash): ?><div class="<?= $flash[0]?'success':'error' ?>"><?= e($flash[1]) ?></div><?php endif; ?>
<div class="cards">
<?php foreach($items as $b): $next=(int)$p[$b]+1; $cost=building_cost($b,$next); ?>
<article class="game-card"><div class="card-icon"><?= ['metal_mine'=>'⛏️','crystal_mine'=>'💎','deuterium_synth'=>'🧪','solar_plant'=>'☀️','research_lab'=>'🔬','shipyard'=>'🚀','metal_storage'=>'📦'][$b] ?></div>
<h2><?= e(building_name($b)) ?></h2><div class="level">المستوى الحالي: <b><?= (int)$p[$b] ?></b></div>
<p>تكلفة المستوى <?= $next ?>: 🔩 <?= fmt($cost['metal']) ?> · 💎 <?= fmt($cost['crystal']) ?></p>
<p>المدة: <?= time_left($cost['time']) ?></p>
<form method="post"><?= csrf_field() ?><input type="hidden" name="building" value="<?= e($b) ?>"><button class="button">ترقية إلى <?= $next ?></button></form>
</article>
<?php endforeach; ?>
</div></section></section>
<?php require 'partials/footer.php'; ?>
