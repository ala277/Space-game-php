<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../app/helpers.php';
require_admin();
$adminUser=current_user();
function admin_head(string $title): void { ?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= e($title) ?> — الإدارة</title><link rel="stylesheet" href="../assets/css/game.css"><style>
.admin-wrap{max-width:1250px;margin:30px auto;padding:0 18px}.admin-nav{display:flex;gap:8px;flex-wrap:wrap;margin:15px 0}.admin-nav a{padding:10px 14px;border:1px solid rgba(255,255,255,.12);border-radius:8px;background:rgba(0,0,0,.25);color:#fff;text-decoration:none}.admin-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.admin-card{padding:18px;border:1px solid rgba(255,255,255,.12);border-radius:12px;background:rgba(8,15,28,.78)}.admin-card h3{margin-top:0}.admin-table{width:100%;border-collapse:collapse}.admin-table th,.admin-table td{padding:9px;border-bottom:1px solid rgba(255,255,255,.1);text-align:right}.admin-table input,.admin-table select,.admin-form input,.admin-form select{max-width:100%;padding:8px}.danger{background:#6b1f2a!important}.ok{color:#7ee2a8}.muted{opacity:.7}.wide-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px}.admin-title{display:flex;justify-content:space-between;align-items:center;gap:12px}.admin-form{display:grid;gap:10px}.admin-form label{display:grid;gap:5px}.check{display:flex!important;align-items:center;gap:8px}.check input{width:auto}
</style></head><body><div class="admin-wrap"><div class="admin-title"><div><h1>🛡️ لوحة الإدارة</h1><div class="muted">صلاحيات واسعة — <?= e($GLOBALS['adminUser']['username'] ?? '') ?></div></div><a class="button" href="../index.php">العودة للعبة</a></div><nav class="admin-nav"><a href="index.php">الرئيسية</a><a href="users.php">اللاعبون</a><a href="control.php">تحكم شامل</a><a href="galaxies.php">المجرات</a><a href="reports.php">التقارير</a><a href="settings.php">الإعدادات</a></nav>
<?php }
function admin_foot(): void { echo '</div></body></html>'; }
