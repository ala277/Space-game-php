<?php require '_layout.php'; $pdo=db();
$stats=[
 'users'=>(int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
 'planets'=>(int)$pdo->query('SELECT COUNT(*) FROM planets')->fetchColumn(),
 'fleets'=>(int)$pdo->query('SELECT COUNT(*) FROM fleets')->fetchColumn(),
 'galaxies'=>(int)$pdo->query('SELECT COUNT(*) FROM galaxies')->fetchColumn(),
 'ships'=>(int)$pdo->query('SELECT COALESCE(SUM(amount),0) FROM ships')->fetchColumn(),
 'reports'=>(int)$pdo->query('SELECT COUNT(*) FROM combat_reports')->fetchColumn(),
];
admin_head('الرئيسية'); ?>
<div class="admin-grid">
<?php foreach(['users'=>'👥 اللاعبون','planets'=>'🪐 الكواكب','fleets'=>'🚀 الأساطيل','galaxies'=>'🌌 المجرات','ships'=>'🛸 مجموع السفن','reports'=>'⚔️ التقارير'] as $k=>$label): ?><div class="admin-card"><h3><?= $label ?></h3><div style="font-size:28px;font-weight:bold"><?= fmt($stats[$k]) ?></div></div><?php endforeach; ?>
</div>
<div class="wide-grid" style="margin-top:16px">
<div class="admin-card"><h2>صلاحيات الأدمن</h2><p>إدارة اللاعبين والكواكب والمجرات، تعديل الموارد والمباني والأبحاث، منح السفن، إنشاء الأساطيل، التحكم بالتقارير وإعدادات اللعبة.</p></div>
<div class="admin-card"><h2>⚠️ تنبيه</h2><p>التغييرات الإدارية مباشرة في قاعدة البيانات. استخدم الصلاحيات بحذر.</p></div>
</div>
<?php admin_foot(); ?>
