<?php
require_once 'config/config.php'; require_once 'app/helpers.php'; require_once 'app/game.php';
require_login(); $uid=(int)$_SESSION['user_id']; $pid=(int)$_SESSION['planet_id'];
process_research_queue($uid);
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf(); [$ok,$msg]=queue_research($uid,$pid,$_POST['tech']??''); $_SESSION['flash']=[ $ok,$msg ]; redirect('research.php');}
$levels=research_levels($uid); $cat=research_catalog();
$q=db()->prepare("SELECT * FROM research_queue WHERE user_id=? AND status='researching' ORDER BY id LIMIT 1");$q->execute([$uid]);$active=$q->fetch();
$title='الأبحاث'; require 'partials/header.php';
?>
<section class="content full"><section class="panel"><h1>مركز الأبحاث</h1>
<?php if(!empty($_SESSION['flash'])): $f=$_SESSION['flash']; unset($_SESSION['flash']); ?><div class="<?= $f[0]?'success':'error' ?>"><?= e($f[1]) ?></div><?php endif; ?>
<?php if($active): ?><div class="queue-row"><span>البحث الجاري: <?= e($cat[$active['technology_key']]['name']) ?> · المستوى <?= (int)$active['target_level'] ?></span><b data-countdown="<?= strtotime($active['finish_at']) ?>">...</b></div><?php endif; ?>
<div class="cards">
<?php foreach($cat as $key=>$r): $next=($levels[$key]??0)+1; $cost=research_cost($key,$next); ?>
<article class="game-card"><div class="card-icon"><?= $r['icon'] ?></div>
<h2><?= e($r['name']) ?></h2><p><?= e($r['description']) ?></p>
<div class="level">المستوى الحالي: <b><?= $levels[$key]??0 ?></b></div>
<p>تكلفة المستوى <?= $next ?>: 🔩 <?= fmt($cost['metal']) ?> · 💎 <?= fmt($cost['crystal']) ?></p>
<p>المدة: <?= time_left($cost['time']) ?></p>
<form method="post"><?= csrf_field() ?><input type="hidden" name="tech" value="<?= e($key) ?>"><button class="button" <?= $active?'disabled':'' ?>>بحث مستوى <?= $next ?></button></form>
</article>
<?php endforeach; ?>
</div></section></section>
<?php require 'partials/footer.php'; ?>
